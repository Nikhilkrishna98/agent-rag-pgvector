import os
from typing import Dict, Any, Optional
from dotenv import load_dotenv

# Load environment variables from env file
# Get the directory where this config file is located
config_dir = os.path.dirname(os.path.abspath(__file__))
# Go up one level to the Meta-agents directory where env is located
project_root = os.path.dirname(config_dir)
env_path = os.path.join(project_root, '.env')

# Load the env file with explicit path
load_dotenv(env_path)

print(f"📁 Loading env from: {env_path}")
print(f"📁 env file exists: {os.path.exists(env_path)}")

class BedrockConfig:
    # AWS Credentials from environment variables
    AWS_ACCESS_KEY_ID = os.getenv("AWS_ACCESS_KEY_ID")
    AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")
    AWS_SESSION_TOKEN =  os.getenv("AWS_SESSION_TOKEN")
    AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
    TEMPERATURE    = 0.3
    MAX_TOKENS     = 8000
    
    # Debug logging for credentials
    print(f"🔑 AWS_ACCESS_KEY_ID loaded: {'✅' if AWS_ACCESS_KEY_ID else '❌'} {AWS_ACCESS_KEY_ID[:10] + '...' if AWS_ACCESS_KEY_ID else 'None'}")
    print(f"🔑 AWS_SECRET_ACCESS_KEY loaded: {'✅' if AWS_SECRET_ACCESS_KEY else '❌'} {AWS_SECRET_ACCESS_KEY[:10] + '...' if AWS_SECRET_ACCESS_KEY else 'None'}")
    print(f"🔑 AWS_SESSION_TOKEN loaded: {'✅' if AWS_SESSION_TOKEN else '❌'} {AWS_SESSION_TOKEN[:20] + '...' if AWS_SESSION_TOKEN else 'None'}")

    
    # Claude Model Configuration
    #CLAUDE_MODEL_ID = os.getenv("CLAUDE_MODEL_ID", "anthropic.claude-3-5-sonnet-20240620-v1:0")
    CLAUDE_TEMPERATURE = float(os.getenv("CLAUDE_TEMPERATURE", "0"))
    CLAUDE_MAX_TOKENS = int(os.getenv("CLAUDE_MAX_TOKENS", "30000"))
    AZURE_DEPLOYMENT_NAME=os.getenv("AZURE_DEPLOYMENT_NAME")
    
    # Langfuse Configuration
    LANGFUSE_PUBLIC_KEY = os.getenv("LANGFUSE_PUBLIC_KEY")
    LANGFUSE_SECRET_KEY = os.getenv("LANGFUSE_SECRET_KEY")
    LANGFUSE_HOST = os.getenv("LANGFUSE_HOST", "https://us.cloud.langfuse.com")
    
    # External API Keys
    SERP_API_KEY = os.getenv("SERP_API_KEY")
    
    # MCP Server Configuration
    MCP_SERVER_URL = os.getenv("MCP_SERVER_URL", "http://localhost:8000/mcp")
    
    @classmethod
    def validate_required_env_vars(cls):
        """
        Validate that all required environment variables are set.
        Only AWS credentials are mandatory; LANGFUSE and SERP_API_KEY are optional.
        """
        # Only require AWS credentials for core functionality
        required_vars = {
            "AWS_ACCESS_KEY_ID": cls.AWS_ACCESS_KEY_ID,
            "AWS_SECRET_ACCESS_KEY": cls.AWS_SECRET_ACCESS_KEY,
        }
        
        missing_vars = []
        for var_name, var_value in required_vars.items():
            if not var_value:
                missing_vars.append(var_name)
        
        if missing_vars:
            raise ValueError(
                f"Missing required environment variables: {', '.join(missing_vars)}\n"
                f"Please set these in your .env file or system environment variables."
            )
        
        # Log optional services that are missing
        optional_vars = {
            "LANGFUSE_PUBLIC_KEY": cls.LANGFUSE_PUBLIC_KEY,
            "LANGFUSE_SECRET_KEY": cls.LANGFUSE_SECRET_KEY,
            "SERP_API_KEY": cls.SERP_API_KEY
        }
        
        missing_optional = [var_name for var_name, var_value in optional_vars.items() if not var_value]
        if missing_optional:
            print(f"⚠️  Optional environment variables not set: {', '.join(missing_optional)}")
    
    @classmethod
    def get_credentials(cls) -> Dict[str, str]:
        # Validate required credentials exist
        cls.validate_required_env_vars()
        
        credentials = {
            'aws_access_key_id': cls.AWS_ACCESS_KEY_ID,
            'aws_secret_access_key': cls.AWS_SECRET_ACCESS_KEY,
            'region_name': cls.AWS_REGION
            
        }
        
        # Only add session token if it exists and is not None/empty
        if cls.AWS_SESSION_TOKEN:
            credentials['aws_session_token'] = cls.AWS_SESSION_TOKEN
        
        return credentials
    
    @classmethod
    def get_model_config(cls) -> Dict[str, Any]:
        return {
            'model': cls.AZURE_DEPLOYMENT_NAME,
            'temperature': cls.CLAUDE_TEMPERATURE,
            'max_tokens': cls.CLAUDE_MAX_TOKENS
        }
