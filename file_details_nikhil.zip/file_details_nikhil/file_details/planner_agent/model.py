"""
Model Configuration
===================

Single file to configure and create the LLM used by all planner agents.

TO SWAP MODELS: only change the config block below.
Nothing else in the codebase needs to change.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
import os 
from langchain.chat_models import init_chat_model
from config.bedrock_config import BedrockConfig
from dotenv import load_dotenv

# Load environment variables from env file
# Get the directory where this config file is located
config_dir = os.path.dirname(os.path.abspath(__file__))
print("***",config_dir)
# Go up one level to the Meta-agents directory where env is located
project_root = os.path.dirname(config_dir)
print("***",project_root)
env_path = os.path.join(project_root, '.env')
print("***",env_path)

# Load the env file with explicit path
load_dotenv(env_path)

print("***",os.getenv("AZURE_DEPLOYMENT_NAME"))

# ─────────────────────────────────────────────────────────────────────
# CHANGE THIS BLOCK TO SWAP MODELS
# ─────────────────────────────────────────────────────────────────────
# MODEL_PROVIDER = "bedrock_converse"                            # e.g. "openai", "azure_openai", "anthropic"
# MODEL_ID       = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"  # e.g. "gpt-4o", "gemini-1.5-pro"
MODEL_PROVIDER = os.getenv("AZURE_DEPLOYMENT_NAME")
MODEL_ID="gpt-4.1"
MODEL_API_KEY=os.getenv("AZURE_API_KEY")
MODEL_API_VERSION=os.getenv("AZURE_API_VERSION")
MODEL_API_BASE=os.getenv("AZURE_API_BASE")
TEMPERATURE    = 0.3
MAX_TOKENS     = 8000
# ─────────────────────────────────────────────────────────────────────


def create_llm():
    """
    Returns the LLM instance used by all planner agents.

    To swap models, change the config block at the top of this file.
    Credentials are loaded from the env file (or environment variables).
    """
    #creds = BedrockConfig.get_credentials()
    return init_chat_model(
        model=MODEL_ID,
        model_provider="azure_openai",
        api_version=MODEL_API_VERSION,
        api_key=MODEL_API_KEY,
        azure_endpoint=MODEL_API_BASE,
        temperature=TEMPERATURE,
        max_tokens=MAX_TOKENS
     #   **creds
    )
