﻿"""
FastAPI endpoint for the Planner Agent System.

Single endpoint: POST /plan
Returns a structured plan + YAML agent config from a user query.
"""

from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from pydantic import BaseModel, Field
from typing import Optional, List
import os
import re
import uuid
from datetime import datetime
from pathlib import Path

from planner_agent.agent import create_llm, PlannerAgent, PlanObserverAgent, AgentConfigGeneratorAgent, PlannerGraph
from planner_agent.schemas import Document
from planner_agent.document_processor import DocumentProcessor

# ====================================================================
# Request / Response Models
# ====================================================================

class PlanRequest(BaseModel):
    """Request body for POST /plan."""
    query: str = Field(
        ...,
        description="The high-level goal or task to decompose into an agent plan.",
        example="Classify emails by intent and extract structured data via an external API."
    )
    max_iterations: Optional[int] = Field(
        default=3, ge=1, le=10,
        description="Maximum planner/observer refinement iterations (1-10)."
    )

class PlanResponse(BaseModel):
    """Response body for POST /plan."""
    success: bool
    message: str
    plan: Optional[dict] = None
    critique: Optional[dict] = None
    iterations: int
    quality_score: Optional[float] = None
    is_acceptable: bool
    agents_config_yaml: Optional[str] = None
    agents_config_yaml_path: Optional[str] = None

# ====================================================================
# App
# ====================================================================

app = FastAPI(
    title="Planner Agent API",
    description="Decomposes a user query into a plan and generates an agents config YAML.",
    version="2.0.0"
)

llm_instance = None
doc_processor = DocumentProcessor()
UPLOAD_DIR = Path("uploaded_documents")
UPLOAD_DIR.mkdir(exist_ok=True)

OUTPUTS_DIR = Path("planner_agent/outputs")
OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)


@app.on_event("startup")
async def startup_event():
    global llm_instance
    print("Initializing LLM...")
    llm_instance = create_llm()
    print("LLM initialized successfully")


@app.get("/")
async def root():
    return {
        "message": "Planner Agent API v2.0",
        "endpoints": {
            "POST /plan": "Generate a plan + agents config YAML from a query",
            "POST /plan/with-documents": "Same, but accepts file uploads as context",
            "GET /health": "Health check"
        }
    }


@app.get("/health")
async def health():
    return {"status": "healthy", "llm_initialized": llm_instance is not None}


def _save_yaml(yaml_str: str, query: str) -> Path:
    """Save agents config YAML to planner_agent/outputs/<timestamp>_agents_config.yaml."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    slug = re.sub(r"[^a-z0-9]+", "_", query.lower())[:40].strip("_")
    filename = OUTPUTS_DIR / f"{timestamp}_{slug}_agents_config.yaml"
    filename.write_text(yaml_str, encoding="utf-8")
    print(f"   Agents config saved → {filename}")
    return filename


def _build_planner_graph(max_iterations: int = 3) -> PlannerGraph:
    """Create a fresh PlannerGraph with all three agents."""
    planner         = PlannerAgent(llm=llm_instance)
    observer        = PlanObserverAgent(llm=llm_instance)
    config_gen      = AgentConfigGeneratorAgent(llm=llm_instance)
    return PlannerGraph(planner, observer, config_gen, max_iterations=max_iterations)


def _build_response(final_state: dict, success_msg_prefix: str = "Plan") -> dict:
    """Extract final state values and build a clean response dict."""
    plan            = final_state.get('plan')
    critique        = final_state.get('critique')
    agents_config   = final_state.get('agents_config')
    iterations      = final_state.get('iteration_count', 0)

    is_acceptable   = critique.is_acceptable if critique else False
    quality_score   = critique.quality_score if critique else None
    quality_ok      = bool(quality_score and quality_score >= 7.0 and iterations >= 2)
    success         = is_acceptable or quality_ok

    message = (
        f"{success_msg_prefix} generated and approved (Quality: {quality_score}/5.0)"
        if success else
        f"{success_msg_prefix} generated (Quality: {quality_score}/5.0). Review suggestions if needed."
    )

    return {
        "success": success,
        "message": message,
        "plan": plan.model_dump() if plan else None,
        "critique": critique.model_dump() if critique else None,
        "iterations": iterations,
        "quality_score": quality_score,
        "is_acceptable": success,
        "agents_config_yaml": agents_config.to_yaml() if agents_config else None
    }


# ====================================================================
# Endpoints
# ====================================================================

@app.post("/plan", response_model=PlanResponse)
async def generate_plan(request: PlanRequest):
    """
    Generate a structured execution plan and an agents config YAML from a user query.

    Returns:
        - plan: the decomposed subgoals
        - agents_config_yaml: YAML string with role, goals, system_prompt per agent
        - quality_score, iterations, is_acceptable
    """
    if llm_instance is None:
        raise HTTPException(status_code=503, detail="LLM not initialized. Please try again.")

    try:
        print(f"\n{'='*60}")
        print(f"New Plan Request: {request.query}")
        print(f"{'='*60}\n")

        graph = _build_planner_graph(request.max_iterations)
        final_state = await graph.run(request.query)

        response = _build_response(final_state)
        if response.get("agents_config_yaml"):
            saved_path = _save_yaml(response["agents_config_yaml"], request.query)
            response["agents_config_yaml_path"] = str(saved_path)
        print(f"\nDone. Quality: {response['quality_score']}  Iterations: {response['iterations']}")
        return response

    except Exception as e:
        print(f"Error: {e}")
        raise HTTPException(status_code=500, detail=f"Planning failed: {str(e)}")


@app.post("/plan/with-documents", response_model=PlanResponse)
async def generate_plan_with_documents(
    query: str = Form(..., description="The high-level goal or task."),
    files: List[UploadFile] = File(default=[], description="Optional reference documents (PDF, DOCX, TXT, CSV, JSON)."),
    max_iterations: int = Form(default=3, ge=1, le=10)
):
    """
    Same as POST /plan but accepts uploaded documents as additional context.
    """
    if llm_instance is None:
        raise HTTPException(status_code=503, detail="LLM not initialized. Please try again.")

    try:
        print(f"\n{'='*60}")
        print(f"New Plan Request (with documents): {query}")
        print(f"Files: {len(files)}")
        print(f"{'='*60}\n")

        # Process uploaded files
        documents: List[Document] = []
        for file in files:
            file_id = str(uuid.uuid4())[:8]
            original_name = file.filename or "unknown"
            file_ext = Path(original_name).suffix.lower()
            saved_path = UPLOAD_DIR / f"{file_id}_{original_name}"

            try:
                content_bytes = await file.read()
                with open(saved_path, "wb") as f:
                    f.write(content_bytes)
            except Exception as e:
                print(f"   Failed to save {original_name}: {e}")
                continue

            if not doc_processor.validate_file(str(saved_path)):
                os.remove(saved_path)
                continue

            try:
                text_content, page_count = doc_processor.load_document(str(saved_path))
                documents.append(Document(
                    content=text_content,
                    source=original_name,
                    page_count=page_count,
                    metadata={"file_id": file_id, "file_type": file_ext}
                ))
                print(f"   Processed: {original_name} ({page_count} pages)")
            except Exception as e:
                print(f"   Failed to process {original_name}: {e}")

        print(f"   Total documents processed: {len(documents)}\n")

        graph = _build_planner_graph(max_iterations)
        final_state = await graph.run(query, documents=documents if documents else None)

        response = _build_response(final_state)
        response["documents_processed"] = len(documents)
        if response.get("agents_config_yaml"):
            saved_path = _save_yaml(response["agents_config_yaml"], query)
            response["agents_config_yaml_path"] = str(saved_path)
        print(f"\nDone. Quality: {response['quality_score']}  Iterations: {response['iterations']}")
        return response

    except Exception as e:
        print(f"Error: {e}")
        raise HTTPException(status_code=500, detail=f"Planning failed: {str(e)}")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("planner_agent.api:app", host="0.0.0.0", port=8004, reload=True)
