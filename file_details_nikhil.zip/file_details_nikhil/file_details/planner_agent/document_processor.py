"""
Document Processor

Handles loading and processing of various document formats.
Supports PDF, DOCX, TXT, MD, CSV, and JSON files.
"""

from typing import List, Optional, Tuple
from pathlib import Path
import os


class DocumentProcessor:
    """
    Process documents of various formats and extract text content.
    
    Supported formats:
    - PDF (.pdf)
    - Word Documents (.docx)
    - Text files (.txt, .md)
    - CSV files (.csv)
    - JSON files (.json)
    """
    
    SUPPORTED_EXTENSIONS = {'.pdf', '.docx', '.txt', '.md', '.csv', '.json', '.xlsx', '.xls'}
    MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB
    
    @staticmethod
    def validate_file(file_path: str) -> bool:
        """
        Validate if file exists, is supported, and within size limits.
        
        Args:
            file_path: Path to the file
            
        Returns:
            True if valid, False otherwise
        """
        path = Path(file_path)
        
        # Check if file exists
        if not path.exists():
            print(f"File not found: {file_path}")
            return False
        
        # Check if it's a file (not directory)
        if not path.is_file():
            print(f"Not a file: {file_path}")
            return False
        
        # Check extension
        if path.suffix.lower() not in DocumentProcessor.SUPPORTED_EXTENSIONS:
            print(f"Unsupported file type: {path.suffix}")
            return False
        
        # Check file size
        file_size = path.stat().st_size
        if file_size > DocumentProcessor.MAX_FILE_SIZE:
            print(f"File too large: {file_size / 1024 / 1024:.1f}MB (max: {DocumentProcessor.MAX_FILE_SIZE / 1024 / 1024}MB)")
            return False
        
        return True
    
    @staticmethod
    def load_document(file_path: str) -> Tuple[str, int]:
        """
        Load document content based on file type.
        
        Args:
            file_path: Path to the document
            
        Returns:
            Tuple of (content, page_count)
            
        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If file type is unsupported
        """
        path = Path(file_path)
        
        if not path.exists():
            raise FileNotFoundError(f"Document not found: {file_path}")
        
        suffix = path.suffix.lower()
        
        if suffix == '.pdf':
            return DocumentProcessor._read_pdf(file_path)
        elif suffix == '.docx':
            return DocumentProcessor._read_docx(file_path)
        elif suffix in ['.txt', '.md']:
            return DocumentProcessor._read_text(file_path)
        elif suffix == '.csv':
            return DocumentProcessor._read_csv(file_path)
        elif suffix == '.json':
            return DocumentProcessor._read_json(file_path)
        elif suffix in ['.xlsx', '.xls']:
            return DocumentProcessor._read_excel(file_path)
        else:
            raise ValueError(f"Unsupported file type: {suffix}")
    
    @staticmethod
    def _read_excel(file_path: str) -> Tuple[str, int]:
        """Read Excel file and convert to text."""
        try:
            import pandas as pd
            
            df = pd.read_excel(file_path)
            content = "Excel Data:\n\n" + df.to_string(index=False)
            page_count = 1
            return content, page_count
            
        except Exception as e:
            raise Exception(f"Error reading Excel: {str(e)}")
    
    @staticmethod
    def _read_pdf(file_path: str) -> Tuple[str, int]:
        """Extract text from PDF file."""
        try:
            from pypdf import PdfReader
            
            reader = PdfReader(file_path)
            pages = []
            
            for i, page in enumerate(reader.pages, 1):
                text = page.extract_text()
                if text.strip():
                    pages.append(f"[Page {i}]\n{text}")
            
            content = "\n\n".join(pages)
            page_count = len(reader.pages)
            
            return content, page_count
            
        except ImportError:
            raise ImportError("pypdf library not installed. Install with: pip install pypdf")
        except Exception as e:
            raise Exception(f"Error reading PDF: {str(e)}")
    
    @staticmethod
    def _read_docx(file_path: str) -> Tuple[str, int]:
        """Extract text from Word document."""
        try:
            import docx
            
            doc = docx.Document(file_path)
            paragraphs = [para.text for para in doc.paragraphs if para.text.strip()]
            content = "\n\n".join(paragraphs)
            
            # Estimate page count (rough: 500 words per page)
            word_count = len(content.split())
            page_count = max(1, word_count // 500)
            
            return content, page_count
            
        except ImportError:
            raise ImportError("python-docx library not installed. Install with: pip install python-docx")
        except Exception as e:
            raise Exception(f"Error reading DOCX: {str(e)}")
    
    @staticmethod
    def _read_text(file_path: str) -> Tuple[str, int]:
        """Read plain text file."""
        try:
            content = Path(file_path).read_text(encoding='utf-8')
            
            # Estimate page count (rough: 3000 characters per page)
            page_count = max(1, len(content) // 3000)
            
            return content, page_count
            
        except Exception as e:
            raise Exception(f"Error reading text file: {str(e)}")
    
    @staticmethod
    def _read_csv(file_path: str) -> Tuple[str, int]:
        """Read CSV file and convert to text."""
        try:
            import csv
            
            with open(file_path, 'r', encoding='utf-8') as f:
                reader = csv.reader(f)
                rows = list(reader)
            
            # Format as table
            content = "CSV Data:\n\n"
            for row in rows:
                content += " | ".join(str(cell) for cell in row) + "\n"
            
            page_count = 1
            
            return content, page_count
            
        except Exception as e:
            raise Exception(f"Error reading CSV: {str(e)}")
    
    @staticmethod
    def _read_json(file_path: str) -> Tuple[str, int]:
        """Read JSON file and convert to text."""
        try:
            import json
            
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # Pretty print JSON
            content = "JSON Data:\n\n" + json.dumps(data, indent=2)
            
            page_count = 1
            
            return content, page_count
            
        except Exception as e:
            raise Exception(f"Error reading JSON: {str(e)}")
    
    @staticmethod
    def chunk_text(text: str, chunk_size: int = 2000, overlap: int = 200) -> List[str]:
        """
        Split text into manageable chunks with overlap.
        
        Args:
            text: Text to chunk
            chunk_size: Maximum words per chunk
            overlap: Number of words to overlap between chunks
            
        Returns:
            List of text chunks
        """
        words = text.split()
        chunks = []
        
        if len(words) <= chunk_size:
            return [text]
        
        i = 0
        while i < len(words):
            chunk_words = words[i:i + chunk_size]
            chunk = " ".join(chunk_words)
            chunks.append(chunk)
            
            # Move forward by (chunk_size - overlap) to create overlap
            i += (chunk_size - overlap)
            
            # Stop if we're at the end
            if i >= len(words):
                break
        
        return chunks
    
    @staticmethod
    def get_file_info(file_path: str) -> dict:
        """
        Get metadata about a file.
        
        Args:
            file_path: Path to the file
            
        Returns:
            Dictionary with file metadata
        """
        path = Path(file_path)
        
        if not path.exists():
            return {}
        
        stat = path.stat()
        
        return {
            "filename": path.name,
            "extension": path.suffix,
            "size_bytes": stat.st_size,
            "size_mb": round(stat.st_size / 1024 / 1024, 2),
            "modified": stat.st_mtime,
            "absolute_path": str(path.absolute())
        }


# Example usage and testing
if __name__ == "__main__":
    print("\n" + "="*70)
    print("TESTING DOCUMENT PROCESSOR")
    print("="*70 + "\n")
    
    processor = DocumentProcessor()
    
    # Test file validation
    test_file = "test.pdf"
    print(f"Testing validation for: {test_file}")
    is_valid = processor.validate_file(test_file)
    print(f"Valid: {is_valid}\n")
    
    # Test supported formats
    print("Supported formats:")
    for ext in processor.SUPPORTED_EXTENSIONS:
        print(f"  - {ext}")
    
    print("\n" + "="*70)
    print("PROCESSOR READY")
    print("="*70 + "\n")
