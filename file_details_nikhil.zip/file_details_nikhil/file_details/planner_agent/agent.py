import json
import asyncio
from typing import List, Dict, Any, Optional

# Pydantic schemas and graph state
from .schemas import Plan, PlanObserverCritique, GraphState, AgentsConfig, Document

# Prompts for the agents
from .prompts import PLANNER_SYSTEM_PROMPT, PLAN_OBSERVER_SYSTEM_PROMPT, AGENT_CONFIG_GENERATOR_PROMPT

# LangGraph components
from langgraph.graph import StateGraph, END

# LLM — change model in planner_agent/model.py
from .model import create_llm
from langchain_core.messages import HumanMessage, AIMessage

# LLM is configured in planner_agent/model.py — import only

# ====================================================================
# Agent Implementations
# ====================================================================

class PlannerAgent:
    def __init__(self, llm):
        self.llm = llm

    def _build_document_context(self, documents: List[Document], max_chars_per_doc: int = 3000) -> str:
        """Build a document context summary for the planner prompt."""
        if not documents:
            return ""
        
        context_parts = ["\n\n**Document Context:**\nThe following documents have been provided as reference material:\n"]
        
        for i, doc in enumerate(documents, 1):
            # Truncate content if too long
            content_preview = doc.content[:max_chars_per_doc]
            if len(doc.content) > max_chars_per_doc:
                content_preview += f"... [truncated, {len(doc.content)} total chars]"
            
            context_parts.append(f"\n--- Document {i}: {doc.source} ---")
            if doc.page_count:
                context_parts.append(f"Pages: {doc.page_count}")
            context_parts.append(f"Content:\n{content_preview}\n")
        
        context_parts.append("\n**Instructions:** Use the document content above to inform your planning. Reference specific data, requirements, or constraints from the documents when relevant.\n")
        
        return "\n".join(context_parts)

    async def generate_plan(self, state: GraphState) -> Plan:
        query = state['user_query']
        critique = state.get('critique')
        documents = state.get('documents')
        
        # Build document context if documents are provided
        document_context = ""
        if documents:
            print(f"\n   [DOCUMENT CONTEXT] Processing {len(documents)} document(s):")
            for doc in documents:
                print(f"      - {doc.source}: {len(doc.content)} chars, {doc.page_count} pages")
            document_context = self._build_document_context(documents)
            print(f"   [DOCUMENT CONTEXT] Added {len(document_context)} chars to prompt")
        else:
            print(f"\n   [DOCUMENT CONTEXT] No documents provided in state")
        
        prompt = f"{PLANNER_SYSTEM_PROMPT}\n\n**User Query:**\n{query}{document_context}"
        if critique:
            # Convert Pydantic model to dict before JSON serialization
            critique_dict = critique.model_dump() if hasattr(critique, 'model_dump') else critique
            prompt += f"\n\n**Observer Feedback (Please Address):**\n```json\n{json.dumps(critique_dict, indent=2)}\n```"
        
        response = await self.llm.ainvoke([HumanMessage(content=prompt)])
        
        # Debug and extract JSON from response
        raw_content = response.content
        print(f"   [DEBUG] Planner response length: {len(raw_content) if raw_content else 0}")
        
        if not raw_content or not raw_content.strip():
            raise ValueError("LLM returned empty response for plan generation")
        
        # Extract JSON from markdown code blocks if present
        content_to_parse = raw_content.strip()
        if "```json" in content_to_parse:
            start = content_to_parse.find("```json") + 7
            end = content_to_parse.find("```", start)
            if end > start:
                content_to_parse = content_to_parse[start:end].strip()
        elif "```" in content_to_parse:
            start = content_to_parse.find("```") + 3
            end = content_to_parse.find("```", start)
            if end > start:
                content_to_parse = content_to_parse[start:end].strip()
        
        try:
            plan_dict = json.loads(content_to_parse)
        except json.JSONDecodeError as e:
            print(f"   [ERROR] Plan JSON parse failed: {e}")
            print(f"   [ERROR] Content: {content_to_parse[:300]}...")
            raise ValueError(f"Failed to parse plan response as JSON: {e}")
        
        return Plan(**plan_dict)

class PlanObserverAgent:
    def __init__(self, llm):
        self.llm = llm

    async def critique_plan(self, plan: Plan) -> PlanObserverCritique:
        prompt = f"{PLAN_OBSERVER_SYSTEM_PROMPT}\n\n**Plan to Review:**\n```json\n{plan.model_dump_json(indent=2)}\n```"
        response = await self.llm.ainvoke([HumanMessage(content=prompt)])
        
        # Extract JSON from response
        raw_content = response.content
        if not raw_content or not raw_content.strip():
            raise ValueError("LLM returned empty response for plan critique")
        
        content_to_parse = raw_content.strip()
        if "```json" in content_to_parse:
            start = content_to_parse.find("```json") + 7
            end = content_to_parse.find("```", start)
            if end > start:
                content_to_parse = content_to_parse[start:end].strip()
        elif "```" in content_to_parse:
            start = content_to_parse.find("```") + 3
            end = content_to_parse.find("```", start)
            if end > start:
                content_to_parse = content_to_parse[start:end].strip()
        
        try:
            critique_dict = json.loads(content_to_parse)
        except json.JSONDecodeError as e:
            print(f"   [ERROR] Critique JSON parse failed: {e}")
            print(f"   [ERROR] Content: {content_to_parse[:300]}...")
            raise ValueError(f"Failed to parse critique response as JSON: {e}")
        
        return PlanObserverCritique(**critique_dict)

class AgentConfigGeneratorAgent:
    """Generates agent configurations (role, goals, system_prompt) from an approved plan."""

    def __init__(self, llm):
        self.llm = llm

    async def generate_config(self, plan: Plan) -> AgentsConfig:
        """Take an approved Plan and produce an AgentsConfig with one entry per subgoal."""
        prompt = (
            f"{AGENT_CONFIG_GENERATOR_PROMPT}\n\n"
            f"**Approved Plan:**\n```json\n{plan.model_dump_json(indent=2)}\n```"
        )
        response = await self.llm.ainvoke([HumanMessage(content=prompt)])

        raw_content = response.content
        print(f"   [DEBUG] Config generator response length: {len(raw_content) if raw_content else 0}")

        if not raw_content or not raw_content.strip():
            raise ValueError("LLM returned empty response for agent config generation")

        content_to_parse = raw_content.strip()
        if "```json" in content_to_parse:
            start = content_to_parse.find("```json") + 7
            end = content_to_parse.find("```", start)
            if end > start:
                content_to_parse = content_to_parse[start:end].strip()
        elif "```" in content_to_parse:
            start = content_to_parse.find("```") + 3
            end = content_to_parse.find("```", start)
            if end > start:
                content_to_parse = content_to_parse[start:end].strip()

        try:
            config_dict = json.loads(content_to_parse)
        except json.JSONDecodeError as e:
            print(f"   [ERROR] Agent config JSON parse failed: {e}")
            print(f"   [ERROR] Content: {content_to_parse[:300]}...")
            raise ValueError(f"Failed to parse agent config response as JSON: {e}")

        return AgentsConfig(**config_dict)

# ====================================================================
# Graph Definition and Execution
# ====================================================================

class PlannerGraph:
    def __init__(
        self,
        planner_agent: PlannerAgent,
        observer_agent: PlanObserverAgent,
        config_generator_agent: AgentConfigGeneratorAgent,
        max_iterations: int = 3
    ):
        self.planner_agent = planner_agent
        self.observer_agent = observer_agent
        self.config_generator_agent = config_generator_agent
        self.max_iterations = max_iterations
        self.graph = self._build_graph()
        self._session_id = None  # Will be set during run()

    def _build_graph(self) -> StateGraph:
        workflow = StateGraph(GraphState)

        # Define the nodes
        workflow.add_node("planner", self.planner_node)
        workflow.add_node("observer", self.observer_node)
        workflow.add_node("config_generator", self.config_generator_node)

        # Entry point: straight to planner (no clarification)
        workflow.set_entry_point("planner")

        # Planner → Observer always
        workflow.add_edge("planner", "observer")

        # Observer → refine (back to planner) or approved (to config_generator)
        workflow.add_conditional_edges(
            "observer",
            self.should_continue,
            {
                "refine": "planner",
                "end": "config_generator"
            }
        )

        # Config generator is always the terminal node
        workflow.add_edge("config_generator", END)

        return workflow

    async def planner_node(self, state: GraphState) -> Dict[str, Any]:
        print("\n>> Entering Planner Node...")
        state['iteration_count'] += 1
        
        # Emit planner node start event
        if self._session_id:
            try:
                import sys
                sys.path.insert(0, str(__file__).replace('planner_agent/agent.py', 'team_foundry_agent'))
                from workflow_tracker import WorkflowTracker, EventTypes
                WorkflowTracker.add_event(self._session_id, EventTypes.PLANNER_NODE_START, {
                    "iteration": state['iteration_count'],
                    "max_iterations": self.max_iterations,
                    "message": f"Generating plan (Iteration {state['iteration_count']}/{self.max_iterations})"
                })
            except Exception as e:
                print(f"[SSE] Failed to emit planner_node_start: {e}")
        
        plan = await self.planner_agent.generate_plan(state)
        print("   - Plan generated.")
        
        # Emit planner node complete event
        if self._session_id:
            try:
                import sys
                sys.path.insert(0, str(__file__).replace('planner_agent/agent.py', 'team_foundry_agent'))
                from workflow_tracker import WorkflowTracker, EventTypes
                subgoals_count = len(plan.plan) if hasattr(plan, 'plan') else 0
                WorkflowTracker.add_event(self._session_id, EventTypes.PLANNER_NODE_COMPLETE, {
                    "iteration": state['iteration_count'],
                    "subgoals_count": subgoals_count,
                    "message": f"Plan generated with {subgoals_count} subgoal(s)"
                })
            except Exception as e:
                print(f"[SSE] Failed to emit planner_node_complete: {e}")
        
        return {"plan": plan, "iteration_count": state['iteration_count']}

    async def observer_node(self, state: GraphState) -> Dict[str, Any]:
        print("\n>> Entering Observer Node...")
        
        # Emit observer node start event
        if self._session_id:
            try:
                import sys
                sys.path.insert(0, str(__file__).replace('planner_agent/agent.py', 'team_foundry_agent'))
                from workflow_tracker import WorkflowTracker, EventTypes
                WorkflowTracker.add_event(self._session_id, EventTypes.OBSERVER_NODE_START, {
                    "iteration": state.get('iteration_count', 1),
                    "message": "Evaluating plan quality..."
                })
            except Exception as e:
                print(f"[SSE] Failed to emit observer_node_start: {e}")
        
        plan = state['plan']
        critique = await self.observer_agent.critique_plan(plan)
        print(f"   - Critique generated. Plan acceptable? {critique.is_acceptable}")
        
        # Extract strengths and weaknesses from PlanAnalysis model
        strengths = []
        weaknesses = []
        if hasattr(critique, 'plan_analysis') and critique.plan_analysis:
            if hasattr(critique.plan_analysis, 'strengths'):
                strengths = critique.plan_analysis.strengths
            if hasattr(critique.plan_analysis, 'weaknesses'):
                weaknesses = critique.plan_analysis.weaknesses
        
        suggestions = []
        if hasattr(critique, 'suggestions_for_improvement'):
            suggestions = critique.suggestions_for_improvement
        
        # Emit observer node complete event with decision
        if self._session_id:
            try:
                import sys
                sys.path.insert(0, str(__file__).replace('planner_agent/agent.py', 'team_foundry_agent'))
                from workflow_tracker import WorkflowTracker, EventTypes
                
                decision = "APPROVED" if critique.is_acceptable else "NEEDS REFINEMENT"
                message = f"Plan {decision} (Quality: {critique.quality_score:.1f}/5.0)"
                
                # Extract individual dimension scores
                dimension_scores = {}
                if hasattr(critique, 'quality_scores'):
                    dimension_scores = {
                        "relevance": critique.quality_scores.relevance,
                        "coverage": critique.quality_scores.coverage,
                        "accuracy": critique.quality_scores.accuracy,
                        "coherence": critique.quality_scores.coherence,
                        "conciseness": critique.quality_scores.conciseness
                    }
                
                WorkflowTracker.add_event(self._session_id, EventTypes.OBSERVER_NODE_COMPLETE, {
                    "iteration": state.get('iteration_count', 1),
                    "quality_score": critique.quality_score,
                    "dimension_scores": dimension_scores,
                    "is_acceptable": critique.is_acceptable,
                    "decision": decision,
                    "message": message,
                    "strengths": strengths,
                    "weaknesses": weaknesses,
                    "suggestions": suggestions
                })
            except Exception as e:
                print(f"[SSE] Failed to emit observer_node_complete: {e}")
        
        return {"critique": critique}

    def should_continue(self, state: GraphState) -> str:
        """Decide whether to continue refining or route to config_generator."""
        critique = state.get('critique')
        iteration_count = state['iteration_count']

        print("\n>> Checking condition...")
        if critique and critique.is_acceptable:
            print(f"   - Plan approved by observer (Quality: {critique.quality_score}). Moving to config generation.")
            return "end"
        elif critique and critique.quality_score >= 7.0 and iteration_count >= 2:
            print(f"   - Plan quality acceptable ({critique.quality_score} >= 7.0) after {iteration_count} iterations. Moving to config generation.")
            return "end"
        elif iteration_count >= self.max_iterations:
            print(f"   - Max iterations reached ({critique.quality_score if critique else 'N/A'}). Moving to config generation with best plan.")
            return "end"
        else:
            print(f"   - Plan needs refinement (Quality: {critique.quality_score if critique else 'N/A'}). Looping back to planner.")
            return "refine"

    async def config_generator_node(self, state: GraphState) -> Dict[str, Any]:
        print("\n>> Entering Config Generator Node...")
        plan = state['plan']
        agents_config = await self.config_generator_agent.generate_config(plan)
        print(f"   - Agent configs generated for {len(agents_config.agents)} agent(s).")
        return {"agents_config": agents_config}

    async def run(self, user_query: str, documents: List[Document] = None, session_id: str = None) -> GraphState:
        """Run the full planning pipeline and return the final state."""
        self._session_id = session_id

        if documents:
            print(f"\n[PlannerGraph.run] Received {len(documents)} document(s):")
            for doc in documents:
                print(f"   - {doc.source}: {len(doc.content)} chars")
        else:
            print(f"\n[PlannerGraph.run] No documents provided")

        app = self.graph.compile()
        initial_state = GraphState(
            user_query=user_query,
            documents=documents,
            plan=None,
            critique=None,
            agents_config=None,
            iteration_count=0
        )
        final_state = await app.ainvoke(initial_state)
        return final_state

# ====================================================================
# Example Usage
# ====================================================================

async def main():
    print("Initializing LLM...")
    llm = create_llm()
    planner = PlannerAgent(llm=llm)
    observer = PlanObserverAgent(llm=llm)
    config_generator = AgentConfigGeneratorAgent(llm=llm)
    print("LLM initialized successfully\n")

    planner_graph = PlannerGraph(planner, observer, config_generator)
    user_query = "Classify emails by intent and extract structured data via an external API"

    print(f"Starting planning process for query: '{user_query}'\n")
    final_state = await planner_graph.run(user_query)

    print("\n" + "="*30 + " FINAL RESULT " + "="*30)
    critique = final_state.get('critique')
    agents_config = final_state.get('agents_config')

    if critique:
        print(f"Quality Score: {critique.quality_score}")
        print(f"Iterations: {final_state['iteration_count']}")
        print("\nFinal Plan:")
        print(final_state['plan'].model_dump_json(indent=2))

    if agents_config:
        print("\nGenerated Agents Config (YAML):")
        print(agents_config.to_yaml())
    else:
        print("No agents config generated.")

if __name__ == "__main__":
    asyncio.run(main())
