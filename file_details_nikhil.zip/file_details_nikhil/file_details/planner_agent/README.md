# Planner-Observer Agent System

An AI-powered planning system that uses a reflection loop to decompose high-level goals into actionable subgoals.

## Architecture

- **Planner Agent**: Decomposes user queries into structured plans with subgoals, dependencies, and expected outputs
- **Plan Observer Agent**: Critically reviews plans, identifies weaknesses, and provides actionable feedback
- **Reflection Loop**: Iteratively refines plans based on Observer feedback until quality threshold is met

## Quick Start

### 1. Start the API Server

From the `Meta-agents` directory:

```bash
python run_planner_api.py
```

The server will start on `http://localhost:8001`

### 2. Access Swagger UI

Open your browser and navigate to:
```
http://localhost:8001/docs
```

### 3. Test via Postman

**Endpoint**: `POST http://localhost:8001/plan`

**Headers**:
```
Content-Type: application/json
```

**Request Body**:
```json
{
  "user_query": "Analyze patient data for the top 10 most frequent diagnosis codes and generate a report.",
  "max_iterations": 3
}
```

**Example Response**:
```json
{
  "success": true,
  "message": "Plan successfully generated and approved (Quality: 8.5/10)",
  "plan": {
    "original_goal": "Analyze patient data for the top 10 most frequent diagnosis codes and generate a report.",
    "reasoning": "Strategic approach to data analysis...",
    "plan": [
      {
        "subgoal_id": "step_1",
        "description": "Retrieve patient encounter data from database",
        "dependencies": [],
        "expected_output": "Raw dataset of patient encounters"
      },
      {
        "subgoal_id": "step_2",
        "description": "Extract and validate diagnosis codes",
        "dependencies": ["step_1"],
        "expected_output": "Clean dataset with ICD-10 codes"
      }
    ]
  },
  "critique": {
    "plan_analysis": {
      "strengths": ["Clear step-by-step approach", "Proper dependencies"],
      "weaknesses": []
    },
    "suggestions_for_improvement": [],
    "is_acceptable": true,
    "quality_score": 8.5
  },
  "iterations": 2,
  "quality_score": 8.5,
  "is_acceptable": true
}
```

## API Endpoints

### `POST /plan`
Generate a high-level plan from a user query.

**Parameters**:
- `user_query` (string, required): The high-level goal to decompose
- `max_iterations` (integer, optional): Maximum refinement iterations (1-10, default: 3)

### `GET /health`
Check API health status.

### `GET /example-queries`
Get example queries organized by category.

### `GET /`
API information and available endpoints.

## Example Queries

### Healthcare Analytics
```json
{
  "user_query": "Identify high-risk patients based on comorbidities and recent hospitalizations."
}
```

### Data Processing
```json
{
  "user_query": "I want to do data transformation for the file I will provide. You need to do data cleaning and EDA."
}
```

### Complex Workflows
```json
{
  "user_query": "Build a predictive model for 30-day hospital readmission risk with feature engineering."
}
```

## Configuration

The system uses the following settings:
- **LLM Model**: Claude 3 Sonnet (via AWS Bedrock)
- **Temperature**: 0.3 (focused planning)
- **Max Tokens**: 8000
- **Quality Threshold**: 7.0/10
- **Max Iterations**: 3 (configurable per request)

## Quality Acceptance Logic

Plans are accepted when:
1. Observer explicitly approves (`is_acceptable: true`), OR
2. Quality score ≥ 7.0 after 2+ iterations (pragmatic threshold), OR
3. Max iterations reached (returns best plan achieved)

## Standalone Usage

You can also run the planner directly without the API:

```bash
python -m planner_agent.agent
```

Edit the `user_query` in `agent.py` to test different scenarios.

## File Structure

```
planner_agent/
├── __init__.py
├── agent.py          # Core agent implementations and graph logic
├── api.py            # FastAPI endpoints
├── prompts.py        # System prompts for Planner and Observer
├── schemas.py        # Pydantic models for Plan and Critique
└── README.md         # This file

run_planner_api.py    # API startup script
```

## Troubleshooting

### LLM Not Initialized
If you see "LLM not initialized", ensure your AWS credentials are properly configured in the `env` file.

### Port Already in Use
If port 8001 is busy, edit `run_planner_api.py` and change the port number.

### Import Errors
Make sure you're running from the `Meta-agents` directory:
```bash
cd Meta-agents
python run_planner_api.py
```
